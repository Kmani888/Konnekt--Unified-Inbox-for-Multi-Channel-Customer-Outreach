import React from 'react';
import AnimatedBackground from './AnimatedBackground';

interface SplashProps {
  onProceed: () => void;
}

const Splash: React.FC<SplashProps> = ({ onProceed }) => {
  const brandName = "Konnekt";

  return (
    <div className="relative h-full w-full bg-black flex flex-col items-center justify-center overflow-hidden">
      <style>{`
        @keyframes orbit {
          0% { transform: rotateY(0deg) rotateX(10deg) translateZ(0); }
          100% { transform: rotateY(360deg) rotateX(10deg) translateZ(0); }
        }
        .animate-orbit {
          animation: orbit 10s linear infinite;
          transform-style: preserve-3d;
        }

        @keyframes pulse-glow {
          0%, 100% { box-shadow: 0 0 15px 5px rgba(0, 180, 255, 0.4); }
          50% { box-shadow: 0 0 25px 10px rgba(0, 220, 255, 0.6); }
        }
        .animate-pulse-glow {
          animation: pulse-glow 3s infinite ease-in-out;
        }
      `}</style>
      
      <AnimatedBackground />

      <div className="z-10 flex flex-col items-center justify-center">
        {/* 3D Orbiting Logo */}
        <div className="mb-4" style={{ perspective: '1000px' }}>
          <div className="relative w-24 h-24 animate-orbit">
            <div className="absolute w-full h-full rounded-full bg-gradient-to-tr from-blue-500 to-cyan-400 shadow-lg shadow-blue-500/50 flex items-center justify-center text-5xl font-bold text-white">
              K
            </div>
          </div>
        </div>
        
        {/* Brand Name */}
        <h1 className="text-7xl font-extrabold text-white tracking-wider mb-6">
          {brandName}
        </h1>

        {/* Tagline Area */}
        <div className="h-8 text-center mb-10">
          <p className="text-xl text-gray-300">
              Your unified communication hub
          </p>
        </div>

        {/* Proceed Button */}
        <button
          onClick={onProceed}
          className="relative w-16 h-16 bg-gray-800 text-white font-semibold rounded-full border-2 border-cyan-400 shadow-lg animate-pulse-glow transition-all duration-300 transform hover:scale-110 focus:outline-none flex items-center justify-center"
          aria-label="Proceed"
        >
          <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path>
          </svg>
        </button>
      </div>
    </div>
  );
};

export default Splash;