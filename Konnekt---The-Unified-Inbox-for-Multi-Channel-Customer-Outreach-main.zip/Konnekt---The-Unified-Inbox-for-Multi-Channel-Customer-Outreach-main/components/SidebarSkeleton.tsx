import React from 'react';

const SidebarSkeleton: React.FC = () => {
  return (
    <aside className="w-80 bg-gray-900 border-r border-gray-700 flex flex-col">
      <style>{`
        @keyframes shimmer {
          0% { background-position: -1000px 0; }
          100% { background-position: 1000px 0; }
        }
        .animate-shimmer {
          animation: shimmer 2s infinite linear;
          background: linear-gradient(to right, #2d3748 25%, #4a5568 50%, #2d3748 75%);
          background-size: 2000px 100%;
        }
      `}</style>
      
      {/* App Header Skeleton */}
      <div className="flex items-center p-4 border-b border-gray-700 space-x-3">
        <div className="w-9 h-9 rounded-lg bg-gray-700 flex-shrink-0 animate-shimmer"></div>
        <div className="h-6 w-32 bg-gray-700 rounded animate-shimmer"></div>
      </div>

      {/* Search Bar Skeleton */}
      <div className="p-4 border-b border-gray-700">
        <div className="h-10 w-full bg-gray-800 rounded-full animate-shimmer"></div>
      </div>
      
      {/* Contact List Skeleton */}
      <div className="flex-grow overflow-y-auto p-3 space-y-3">
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="flex items-center">
            <div className="w-12 h-12 rounded-full mr-3 bg-gray-700 animate-shimmer"></div>
            <div className="flex-grow space-y-2">
              <div className="h-4 w-3/4 bg-gray-700 rounded animate-shimmer"></div>
              <div className="h-3 w-full bg-gray-700 rounded animate-shimmer"></div>
            </div>
          </div>
        ))}
      </div>
      
       {/* User Profile Skeleton */}
       <div className="p-4 border-t border-gray-700 flex items-center">
         <div className="w-10 h-10 rounded-full mr-3 bg-gray-700 animate-shimmer"></div>
         <div className="space-y-2">
            <div className="h-4 w-24 bg-gray-700 rounded animate-shimmer"></div>
            <div className="h-3 w-16 bg-gray-700 rounded animate-shimmer"></div>
         </div>
       </div>
    </aside>
  );
};

export default SidebarSkeleton;