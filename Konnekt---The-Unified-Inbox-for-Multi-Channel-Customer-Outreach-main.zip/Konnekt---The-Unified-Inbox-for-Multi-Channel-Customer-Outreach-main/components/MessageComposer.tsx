import React, { useState, forwardRef, useRef } from 'react';
import type { Contact, User, Message } from '../types';
import { ChannelType } from '../types';
import { SendIcon } from './icons/SendIcon';
import { AttachmentIcon } from './icons/AttachmentIcon';

interface MessageComposerProps {
  contact: Contact;
  user: User;
  onSendMessage: (message: Omit<Message, 'id' | 'timestamp' | 'direction'>) => void;
  activeChannel: ChannelType;
}

const getPlaceholderText = (channel: ChannelType): string => {
  switch (channel) {
    case ChannelType.SMS:
      return 'Type an SMS message...';
    case ChannelType.WhatsApp:
      return 'Type a WhatsApp message...';
    case ChannelType.Email:
      return 'Compose your email body...';
    default:
      return 'Type a message...';
  }
};

const MessageComposer = forwardRef<HTMLTextAreaElement, MessageComposerProps>(
  ({ contact, user, onSendMessage, activeChannel }, ref) => {
    const [text, setText] = useState('');
    const [subject, setSubject] = useState('');
    const [attachedFile, setAttachedFile] = useState<File | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleAttachClick = () => {
        fileInputRef.current?.click();
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setAttachedFile(e.target.files[0]);
        }
    };

    const handleRemoveAttachment = () => {
        setAttachedFile(null);
        if (fileInputRef.current) {
            fileInputRef.current.value = ""; // Reset file input
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      const fileText = attachedFile ? `[File attached: ${attachedFile.name}]\n` : '';
      const messageText = `${fileText}${text.trim()}`;

      if (messageText.trim() || (activeChannel === ChannelType.Email && subject.trim())) {
        const messageData = {
          contactId: contact.id,
          text: messageText,
          channel: activeChannel,
          ...(activeChannel === ChannelType.Email && { subject: subject.trim() || '(no subject)' }),
        };
        onSendMessage(messageData);
        setText('');
        setSubject('');
        handleRemoveAttachment();
      }
    };

    return (
      <div className="p-4 bg-gray-900/80 backdrop-blur-lg border-t border-gray-700/50">
        <form onSubmit={handleSubmit} className="flex flex-col gap-2">
           <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
          {activeChannel === ChannelType.Email && (
            <input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="Subject"
              className="w-full bg-gray-800/70 border border-gray-700/80 rounded-lg py-2 px-4 focus:outline-none focus:ring-2 focus:ring-cyan-500"
            />
          )}
          {attachedFile && (
            <div className="flex items-center justify-between text-sm bg-gray-800/70 p-2 rounded-md border border-gray-700/80 text-left">
              <span className="truncate text-gray-300">
                Attached: {attachedFile.name}
              </span>
              <button
                type="button"
                onClick={handleRemoveAttachment}
                className="text-gray-400 hover:text-white font-bold text-lg leading-none ml-2 flex-shrink-0"
                aria-label="Remove attachment"
              >
                &times;
              </button>
            </div>
           )}
          <div className="flex items-center gap-2">
            <button type="button" onClick={handleAttachClick} className="p-2 text-gray-400 hover:text-white flex-shrink-0">
              <AttachmentIcon className="w-6 h-6" />
            </button>
            <textarea
              ref={ref}
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  handleSubmit(e);
                }
              }}
              placeholder={getPlaceholderText(activeChannel)}
              className="w-full bg-gray-800/70 border border-gray-700/80 rounded-lg py-2 px-4 resize-none focus:outline-none focus:ring-2 focus:ring-cyan-500"
              rows={1}
            />
            <button
              type="submit"
              className="p-3 bg-cyan-600 text-white rounded-full hover:bg-cyan-700 disabled:bg-gray-600 transition flex-shrink-0"
              disabled={!text.trim() && !subject.trim() && !attachedFile}
              aria-label="Send message"
            >
              <SendIcon className="w-6 h-6" />
            </button>
          </div>
        </form>
      </div>
    );
  }
);

export default MessageComposer;