import React, { useState } from 'react';
import type { User } from '../types';
import AnimatedBackground from './AnimatedBackground';
import { login } from '../api';

interface UserInfoEntryProps {
  onInfoSubmit: (user: User) => void;
}

const UserInfoEntry: React.FC<UserInfoEntryProps> = ({ onInfoSubmit }) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const numericValue = e.target.value.replace(/[^0-9]/g, '');
    setPhone(numericValue);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = name.trim();

    if (trimmedName.length < 3) {
      setError('Username must be at least 3 characters long.');
      return;
    }
     if (!/^[A-Za-z]+$/.test(trimmedName)) {
      setError('Username can only contain letters (a-z, A-Z).');
      return;
    }
    if (phone.trim().length < 10) {
        setError('Phone number must be at least 10 digits.');
        return;
    }
    if (!/^\S+@gmail\.com$/.test(email)) {
        setError('Please enter a valid email ending with @gmail.com.');
        return;
    }

    setError('');
    setIsLoading(true);
    try {
      const user = await login({
        name: trimmedName,
        phone: phone.trim(),
        email: email.trim(),
      });
      onInfoSubmit(user);
    } catch (apiError)  {
      setError('Login failed. Please try again.');
      setIsLoading(false);
    }
  };

  return (
    <div className="relative flex items-center justify-center h-screen bg-black overflow-hidden">
      <AnimatedBackground />
      <div className="relative z-10 w-full max-w-sm p-8 space-y-6 bg-gray-900 rounded-lg shadow-2xl shadow-cyan-500/10">
        <h1 className="text-4xl font-extrabold text-center text-white tracking-wider">Konnekt</h1>
        <p className="text-center text-gray-400">Create your account to begin.</p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="username" className="block text-sm font-medium text-gray-300 mb-1">
              Username
            </label>
            <input
              id="username"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 text-white bg-gray-800 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-cyan-500 transition"
              placeholder="e.g., AlexRyder"
              autoFocus
            />
          </div>
           <div>
            <label htmlFor="phone" className="block text-sm font-medium text-gray-300 mb-1">
              Mobile Number
            </label>
            <input
              id="phone"
              type="tel"
              value={phone}
              onChange={handlePhoneChange}
              className="w-full px-3 py-2 text-white bg-gray-800 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-cyan-500 transition"
              placeholder="e.g., 5551234567"
            />
          </div>
           <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-1">
              Email Address
            </label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3 py-2 text-white bg-gray-800 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-cyan-500 transition"
              placeholder="alex.ryder@gmail.com"
            />
          </div>
          <button
            type="submit"
            disabled={isLoading}
            className="w-full px-4 py-3 font-semibold text-white bg-cyan-600 rounded-md hover:bg-cyan-700 transition duration-300 transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-cyan-400 !mt-6 disabled:bg-gray-600 disabled:cursor-not-allowed disabled:scale-100"
          >
            {isLoading ? 'Creating Account...' : 'Continue'}
          </button>
        </form>
        {error && <p className="mt-2 text-sm text-center text-red-400">{error}</p>}
      </div>
    </div>
  );
};

export default UserInfoEntry;