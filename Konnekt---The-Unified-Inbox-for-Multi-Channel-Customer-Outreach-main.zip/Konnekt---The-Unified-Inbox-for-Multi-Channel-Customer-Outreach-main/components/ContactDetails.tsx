import React from 'react';
import type { Contact } from '../types';

interface ContactDetailsProps {
  contact: Contact | null;
}

const ContactDetails: React.FC<ContactDetailsProps> = ({ contact }) => {
  if (!contact) {
    return (
       <aside className="w-96 bg-gray-900/80 backdrop-blur-lg border-l border-gray-700/50 flex flex-col p-6 items-center justify-center flex-shrink-0">
         <p className="text-gray-500 text-center">Select a contact to view their details.</p>
       </aside>
    );
  }

  return (
    <aside className="w-96 bg-gray-900/80 backdrop-blur-lg border-l border-gray-700/50 flex flex-col flex-shrink-0">
      {/* Header */}
      <div className="flex flex-col items-center p-6 border-b border-gray-700/50 text-center">
        <img src={contact.avatarUrl} alt={contact.name} className="w-24 h-24 rounded-full mb-4 ring-2 ring-cyan-500 p-1 object-cover" />
        <h2 className="text-xl font-bold text-white">{contact.name}</h2>
      </div>

      {/* Spacer to push footer down */}
      <div className="flex-grow"></div>

      {/* Footer Actions */}
      <div className="p-4 border-t border-gray-700/50 flex items-center justify-around">
         <button className="text-gray-400 hover:text-white transition-colors text-xs flex flex-col items-center gap-1">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20.66A10.003 10.003 0 0112 11a10.003 10.003 0 019 9.66" /></svg>
          Add Task
         </button>
         <button className="text-gray-400 hover:text-white transition-colors text-xs flex flex-col items-center gap-1">
           <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
           Schedule
         </button>
      </div>
    </aside>
  );
};

export default ContactDetails;