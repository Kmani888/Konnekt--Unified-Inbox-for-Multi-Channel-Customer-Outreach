import React from 'react';

const InboxSkeleton: React.FC = () => {
  return (
    <div className="flex flex-col h-full">
      <style>{`
        @keyframes shimmer {
          0% { background-position: -1000px 0; }
          100% { background-position: 1000px 0; }
        }
        .animate-shimmer {
          animation: shimmer 2s infinite linear;
          background: linear-gradient(to right, #2d3748 25%, #4a5568 50%, #2d3748 75%);
          background-size: 2000px 100%;
        }
      `}</style>
      
      {/* Header Skeleton */}
      <header className="flex items-center p-4 bg-gray-900 border-b border-gray-700">
        <div className="w-10 h-10 rounded-full mr-4 bg-gray-700 animate-shimmer"></div>
        <div className="space-y-2">
          <div className="h-5 w-32 bg-gray-700 rounded animate-shimmer"></div>
          <div className="h-3 w-20 bg-gray-700 rounded animate-shimmer"></div>
        </div>
      </header>
      
      {/* Tabs Skeleton */}
      <div className="p-2 bg-gray-800 border-b border-gray-700 flex items-center space-x-2">
        <div className="h-9 w-20 bg-gray-700 rounded-md animate-shimmer"></div>
        <div className="h-9 w-24 bg-gray-700 rounded-md animate-shimmer"></div>
        <div className="h-9 w-20 bg-gray-700 rounded-md animate-shimmer"></div>
      </div>


      {/* Messages Skeleton */}
      <div className="flex-grow p-4 overflow-y-auto bg-gray-800 space-y-4">
        <div className="flex items-end gap-2 justify-start">
            <div className="w-8 h-8 rounded-full bg-gray-700 animate-shimmer"></div>
            <div className="h-12 w-48 bg-gray-700 rounded-2xl rounded-bl-none animate-shimmer"></div>
        </div>
         <div className="flex items-end gap-2 justify-end">
            <div className="h-16 w-64 bg-cyan-600/50 rounded-2xl rounded-br-none animate-shimmer"></div>
        </div>
         <div className="flex items-end gap-2 justify-start">
            <div className="w-8 h-8 rounded-full bg-gray-700 animate-shimmer"></div>
            <div className="h-10 w-32 bg-gray-700 rounded-2xl rounded-bl-none animate-shimmer"></div>
        </div>
        <div className="flex items-end gap-2 justify-end">
            <div className="h-12 w-40 bg-cyan-600/50 rounded-2xl rounded-br-none animate-shimmer"></div>
        </div>
      </div>
      
      {/* Composer Skeleton */}
      <div className="p-4 bg-gray-900 border-t border-gray-700">
        <div className="flex items-center gap-2">
           <div className="w-10 h-10 rounded-full bg-gray-800 animate-shimmer"></div>
           <div className="flex-grow h-10 rounded-lg bg-gray-800 animate-shimmer"></div>
           <div className="w-12 h-12 rounded-full bg-gray-800 animate-shimmer"></div>
        </div>
      </div>
    </div>
  );
};

export default InboxSkeleton;