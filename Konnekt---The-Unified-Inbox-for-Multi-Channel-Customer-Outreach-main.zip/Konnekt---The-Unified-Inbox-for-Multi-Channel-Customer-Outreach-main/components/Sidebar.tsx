import React, { useState, useEffect } from 'react';
import type { Contact, User } from '../types';
import { SearchIcon } from './icons/SearchIcon';
import { UserIcon } from './icons/UserIcon';
import { ImportIcon } from './icons/ImportIcon';
import { SpinnerIcon } from './icons/SpinnerIcon';

interface SidebarProps {
  user: User;
  contacts: Contact[];
  selectedContact: Contact | null;
  onSelectContact: (contact: Contact) => void;
  onImportContacts: () => Promise<void>;
  isImporting: boolean;
  importStatus: { message: string; type: 'success' | 'error' } | null;
}

const Sidebar: React.FC<SidebarProps> = ({ user, contacts, selectedContact, onSelectContact, onImportContacts, isImporting, importStatus }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isApiSupported, setIsApiSupported] = useState(false);

  useEffect(() => {
    if ('contacts' in navigator && 'ContactsManager' in window) {
      setIsApiSupported(true);
    }
  }, []);

  const filteredContacts = contacts.filter(contact =>
    contact.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  // No longer sorting here to preserve the order (newly imported at top)
  // .sort((a, b) => a.name.localeCompare(b.name));

  const importButtonTitle = isApiSupported 
    ? "Import contacts from your device" 
    : "Contact Picker API is not supported by your browser.";

  return (
    <aside className="w-80 bg-gray-900/80 backdrop-blur-lg border-r border-gray-700/50 flex flex-col">
      {/* App Header */}
      <div className="flex items-center p-4 border-b border-gray-700/50 space-x-3">
        <div className="w-9 h-9 rounded-lg bg-gradient-to-tr from-blue-500 to-cyan-400 flex items-center justify-center text-xl font-bold text-white flex-shrink-0">
          K
        </div>
        <h1 className="text-xl font-bold text-white">Konnekt</h1>
      </div>

      <div className="p-4 border-b border-gray-700/50 space-y-2">
        <div className="relative">
          <input
            type="text"
            placeholder="Search contacts..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-gray-800/70 border border-gray-600/80 rounded-full py-2 pl-10 pr-4 focus:outline-none focus:ring-2 focus:ring-cyan-500 text-sm"
          />
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <SearchIcon className="h-5 w-5 text-gray-400" />
          </div>
        </div>
        <button
            onClick={onImportContacts}
            disabled={!isApiSupported || isImporting}
            title={importButtonTitle}
            className="w-full flex items-center justify-center gap-2 bg-gray-800/70 border border-gray-600/80 rounded-full py-2 px-4 focus:outline-none focus:ring-2 focus:ring-cyan-500 text-sm hover:bg-gray-700/70 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
            {isImporting ? (
                <>
                    <SpinnerIcon className="h-5 w-5 animate-spin" />
                    <span>Importing...</span>
                </>
            ) : (
                <>
                    <ImportIcon className="h-5 w-5 text-gray-400" />
                    <span>Import Contacts</span>
                </>
            )}
        </button>
        {importStatus && (
          <div className={`p-2 text-center text-xs rounded-md transition-opacity duration-300 ${importStatus.type === 'success' ? 'bg-green-500/20 text-green-300' : 'bg-red-500/20 text-red-300'}`}>
            {importStatus.message}
          </div>
        )}
      </div>
      <div className="flex-grow overflow-y-auto">
        {filteredContacts.map(contact => (
          <div
            key={contact.id}
            onClick={() => onSelectContact(contact)}
            className={`flex items-center p-3 cursor-pointer transition-colors duration-200 ${
              selectedContact?.id === contact.id ? 'bg-cyan-600/30' : 'hover:bg-gray-800/50'
            }`}
          >
            <img src={contact.avatarUrl} alt={contact.name} className="w-12 h-12 rounded-full mr-3 object-cover" />
            <div className="flex-grow overflow-hidden">
              <div className="flex justify-between items-center">
                <h3 className="font-semibold text-white truncate">{contact.name}</h3>
                <span className="text-xs text-gray-400">{contact.lastMessageTimestamp}</span>
              </div>
              <div className="flex justify-between items-start">
                <p className="text-sm text-gray-400 truncate pr-2">{contact.lastMessage}</p>
                {contact.unreadCount > 0 && selectedContact?.id !== contact.id && (
                  <span className="bg-cyan-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center flex-shrink-0">
                    {contact.unreadCount}
                  </span>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
       <div className="p-4 border-t border-gray-700/50 flex items-center">
         <UserIcon className="w-10 h-10 rounded-full mr-3 bg-gray-700 p-2"/>
         <div>
            <p className="font-semibold">{user.name}</p>
            <p className="text-sm text-gray-400">Online</p>
         </div>
       </div>
    </aside>
  );
};

export default Sidebar;