import React, { useState, useEffect } from 'react';
import Sidebar from './Sidebar';
import Inbox from './Inbox';
import type { Contact, Message, User } from '../types';
import { ChannelType } from '../types';
import SidebarSkeleton from './SidebarSkeleton';
import InboxSkeleton from './InboxSkeleton';
import AnimatedBackground from './AnimatedBackground';
import { getContacts, getMessages, postMessage } from '../api';

const MainApp: React.FC<{ user: User }> = ({ user }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [isImporting, setIsImporting] = useState(false);
  const [importStatus, setImportStatus] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);
  const [activeChannel, setActiveChannel] = useState<ChannelType>(ChannelType.SMS);


  useEffect(() => {
    if (importStatus) {
      const timer = setTimeout(() => setImportStatus(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [importStatus]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        console.log("Fetching data from API...");
        const [fetchedContacts, fetchedMessages] = await Promise.all([
          getContacts(),
          getMessages(),
        ]);
        
        console.log("API data received.");
        setContacts(fetchedContacts);
        setMessages(fetchedMessages);
        if (fetchedContacts.length > 0) {
          setSelectedContact(fetchedContacts[0]);
        }
      } catch (error) {
        console.error("Failed to fetch initial data", error);
        // Here you could set an error state to show in the UI
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleSelectContact = (contact: Contact) => {
    setSelectedContact(contact);
    setActiveChannel(ChannelType.SMS);
  };

  const handleSendMessage = async (newMessageData: Omit<Message, 'id' | 'timestamp' | 'direction'>) => {
    const tempId = `temp_${Date.now()}`;
    // Optimistic update
    const optimisticMessage: Message = {
        id: tempId,
        timestamp: 'Sending...',
        direction: 'outgoing',
        ...newMessageData,
    };
    
    setMessages(prevMessages => [...prevMessages, optimisticMessage]);

    setContacts(prevContacts => prevContacts.map(c => 
      c.id === newMessageData.contactId ? { ...c, lastMessage: newMessageData.text, lastMessageTimestamp: 'Just now' } : c
    ));
    
    try {
        const savedMessage = await postMessage(newMessageData);
        // Replace optimistic message with the real one from the server
        setMessages(prevMessages => 
            prevMessages.map(m => m.id === tempId ? savedMessage : m)
        );
    } catch (error) {
        console.error("Failed to send message", error);
        // Revert the optimistic update on error
        setMessages(prevMessages => prevMessages.filter(m => m.id !== tempId));
        // TODO: Revert contact's last message and show an error toast to the user
    }
  };

  const handleImportContacts = async () => {
    if (!('contacts' in navigator && 'ContactsManager' in window)) {
      setImportStatus({ message: 'Contact API not supported.', type: 'error' });
      return;
    }

    try {
      setIsImporting(true);
      setImportStatus(null);
      const props = ['name', 'email', 'tel', 'icon'];
      // @ts-ignore
      const pickedContacts = await navigator.contacts.select(props, { multiple: true });

      if (pickedContacts.length > 0) {
        const newContacts: Contact[] = [];
        const existingPhones = new Set(contacts.map(c => c.phone));

        for (const pickedContact of pickedContacts) {
          const phone = pickedContact.tel?.[0];
          if (phone && !existingPhones.has(phone)) {
            let avatarUrl = `https://picsum.photos/seed/${phone}/100/100`;
            if (pickedContact.icon && pickedContact.icon[0]) {
               avatarUrl = URL.createObjectURL(pickedContact.icon[0]);
            }
            
            newContacts.push({
              id: phone, // Use phone as a unique ID
              name: pickedContact.name?.[0] || 'No Name',
              avatarUrl,
              phone: phone,
              email: pickedContact.email?.[0] || '',
              lastMessage: 'Contact imported.',
              lastMessageTimestamp: 'Just now',
              unreadCount: 0,
            });
            existingPhones.add(phone);
          }
        }
        
        if (newContacts.length > 0) {
          setContacts(prevContacts => [...newContacts, ...prevContacts]);
          setImportStatus({ message: `${newContacts.length} new contact(s) imported!`, type: 'success' });
        } else {
          setImportStatus({ message: 'Selected contacts already exist.', type: 'error' });
        }
      }
    } catch (error) {
      if (error instanceof DOMException && error.name === 'AbortError') {
        console.log('Contact selection cancelled by user.');
        setImportStatus({ message: 'Import cancelled.', type: 'error' });
      } else {
        console.error('Error picking contacts:', error);
        setImportStatus({ message: 'Could not import contacts.', type: 'error' });
      }
    } finally {
      setIsImporting(false);
    }
  };


  if (isLoading) {
    return (
      <div className="flex h-screen w-screen bg-gray-900 text-gray-200 font-sans">
        <SidebarSkeleton />
        <main className="flex flex-col flex-grow bg-gray-800">
          <InboxSkeleton />
        </main>
      </div>
    );
  }

  return (
    <div
      className="relative h-screen w-screen bg-black text-gray-200 font-sans overflow-hidden"
    >
      <AnimatedBackground />
      <div 
        className="relative flex h-full w-full"
      >
        <Sidebar
          user={user}
          contacts={contacts}
          selectedContact={selectedContact}
          onSelectContact={handleSelectContact}
          onImportContacts={handleImportContacts}
          isImporting={isImporting}
          importStatus={importStatus}
        />
        <main className="flex flex-col flex-grow bg-gray-800/80 backdrop-blur-lg">
          {selectedContact ? (
            <Inbox
              contact={selectedContact}
              messages={messages.filter(m => m.contactId === selectedContact.id)}
              user={user}
              onSendMessage={handleSendMessage}
              activeChannel={activeChannel}
              setActiveChannel={setActiveChannel}
            />
          ) : (
            <div className="flex items-center justify-center h-full">
              <p className="text-gray-500">Select a contact to start messaging</p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default MainApp;