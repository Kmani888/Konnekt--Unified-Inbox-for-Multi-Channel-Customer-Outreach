import React, { useState, useRef } from 'react';
import type { Contact, Message, User } from '../types';
import { ChannelType } from '../types';
import MessageComposer from './MessageComposer';
import VoipCallModal from './VoipCallModal';
import { ChatIcon } from './icons/ChatIcon';
import { WhatsAppIcon } from './icons/WhatsAppIcon';
import { EmailIcon } from './icons/EmailIcon';
import { TwitterIcon } from './icons/TwitterIcon';
import { PhoneIcon } from './icons/PhoneIcon';
import { ReplyIcon } from './icons/ReplyIcon';

interface InboxProps {
  contact: Contact;
  messages: Message[];
  user: User;
  onSendMessage: (message: Omit<Message, 'id' | 'timestamp' | 'direction'>) => void;
  activeChannel: ChannelType;
  setActiveChannel: (channel: ChannelType) => void;
}

const ChannelIcon: React.FC<{ channel: ChannelType }> = ({ channel }) => {
  const iconProps = { className: "w-4 h-4" };
  switch (channel) {
    case ChannelType.SMS: return <ChatIcon {...iconProps} />;
    case ChannelType.WhatsApp: return <WhatsAppIcon {...iconProps} />;
    case ChannelType.Email: return <EmailIcon {...iconProps} />;
    case ChannelType.Twitter: return <TwitterIcon {...iconProps} />;
    default: return null;
  }
};

const ChannelTab: React.FC<{
  channel: ChannelType;
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
  onClick: () => void;
}> = ({ icon, label, isActive, onClick }) => (
  <button
    onClick={onClick}
    className={`flex items-center space-x-2 px-4 py-2 text-sm font-medium rounded-md transition-colors ${
      isActive ? 'bg-cyan-600 text-white' : 'text-gray-300 hover:bg-gray-700/50'
    }`}
  >
    {icon}
    <span>{label}</span>
  </button>
);

const Inbox: React.FC<InboxProps> = ({ contact, messages, user, onSendMessage, activeChannel, setActiveChannel }) => {
  const composerInputRef = useRef<HTMLTextAreaElement>(null);
  const [isCalling, setIsCalling] = useState(false);

  const handleReplyClick = () => {
    composerInputRef.current?.focus();
  };
  
  const filteredMessages = messages.filter(m => m.channel === activeChannel);

  return (
    <div className="flex flex-col h-full">
      <header className="flex items-center p-4 bg-gray-900/80 backdrop-blur-lg border-b border-gray-700/50 shadow-md">
        <img src={contact.avatarUrl} alt={contact.name} className="w-10 h-10 rounded-full mr-4" />
        <div>
          <h2 className="text-lg font-bold text-white">{contact.name}</h2>
          <p className="text-sm text-gray-400">Online</p>
        </div>
        <div className="ml-auto">
          <button onClick={() => setIsCalling(true)} className="p-2 rounded-full hover:bg-gray-700/50 transition">
            <PhoneIcon className="w-6 h-6 text-gray-300" />
          </button>
        </div>
      </header>
      
      <div className="p-2 bg-gray-800/50 border-b border-gray-700/50 flex items-center space-x-2">
         <ChannelTab 
            channel={ChannelType.SMS}
            icon={<ChatIcon className="w-5 h-5"/>}
            label="SMS"
            isActive={activeChannel === ChannelType.SMS}
            onClick={() => setActiveChannel(ChannelType.SMS)}
         />
         <ChannelTab 
            channel={ChannelType.WhatsApp}
            icon={<WhatsAppIcon className="w-5 h-5"/>}
            label="WhatsApp"
            isActive={activeChannel === ChannelType.WhatsApp}
            onClick={() => setActiveChannel(ChannelType.WhatsApp)}
         />
         <ChannelTab 
            channel={ChannelType.Email}
            icon={<EmailIcon className="w-5 h-5"/>}
            label="Email"
            isActive={activeChannel === ChannelType.Email}
            onClick={() => setActiveChannel(ChannelType.Email)}
         />
      </div>


      <div className="flex-grow p-4 overflow-y-auto">
        <div className="space-y-4">
          {filteredMessages.map(message => (
            <div
              key={message.id}
              className={`relative flex items-end gap-2 group ${message.direction === 'outgoing' ? 'justify-end' : 'justify-start'}`}
            >
              {message.direction === 'incoming' && (
                <button
                  onClick={handleReplyClick}
                  className="absolute left-0 top-1/2 -translate-y-1/2 p-1.5 rounded-full text-gray-400 hover:bg-gray-700 hover:text-white transition-all opacity-0 group-hover:opacity-100 focus:opacity-100"
                  aria-label="Reply to message"
                  title="Reply"
                >
                  <ReplyIcon className="w-5 h-5" />
                </button>
              )}
              {message.direction === 'incoming' && <img src={contact.avatarUrl} className="w-8 h-8 rounded-full ml-10" alt="contact"/>}
              <div
                className={`max-w-xl p-3 rounded-2xl flex flex-col ${
                  message.direction === 'outgoing'
                    ? 'bg-cyan-600 text-white rounded-br-none'
                    : 'bg-gray-700 text-gray-200 rounded-bl-none'
                }`}
              >
                {message.subject && <strong className="text-sm font-bold mb-1 border-b border-white/20 pb-1">{message.subject}</strong>}
                <p className="text-sm whitespace-pre-wrap">{message.text}</p>
                {message.direction === 'outgoing' && (
                  <span className={`text-xs mt-1 self-end ${message.id.startsWith('temp_') ? 'text-cyan-200' : 'text-cyan-100/70'}`}>
                    {message.timestamp}
                  </span>
                )}
              </div>
              {message.direction === 'outgoing' && <div className="w-8 h-8"></div>}
            </div>
          ))}
           {filteredMessages.length === 0 && (
             <div className="text-center text-gray-500 pt-10">
                No messages in this channel.
             </div>
           )}
        </div>
      </div>
      
      <MessageComposer ref={composerInputRef} contact={contact} user={user} onSendMessage={onSendMessage} activeChannel={activeChannel}/>
      
      {isCalling && (
        <VoipCallModal contact={contact} onClose={() => setIsCalling(false)} />
      )}
    </div>
  );
};

export default Inbox;