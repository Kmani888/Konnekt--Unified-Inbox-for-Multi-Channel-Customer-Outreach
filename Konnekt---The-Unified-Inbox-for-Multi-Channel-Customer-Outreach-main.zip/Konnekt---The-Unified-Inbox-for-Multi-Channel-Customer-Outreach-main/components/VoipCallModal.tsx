import React from 'react';
import type { Contact } from '../types';
import { EndCallIcon } from './icons/EndCallIcon';

interface VoipCallModalProps {
  contact: Contact;
  onClose: () => void;
}

const VoipCallModal: React.FC<VoipCallModalProps> = ({ contact, onClose }) => {
  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 animate-fade-in">
      <style>{`
        @keyframes fade-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        .animate-fade-in {
          animation: fade-in 0.3s ease-out forwards;
        }
      `}</style>
      <div className="bg-gray-800 rounded-2xl p-8 text-center flex flex-col items-center gap-4 shadow-2xl shadow-cyan-500/10 w-full max-w-sm">
        <img src={contact.avatarUrl} alt={contact.name} className="w-28 h-28 rounded-full ring-4 ring-cyan-500/50 object-cover" />
        <h2 className="text-3xl font-bold text-white mt-2">{contact.name}</h2>
        <p className="text-cyan-400 text-lg animate-pulse">Calling...</p>
        <button
          onClick={onClose}
          className="mt-6 bg-red-600 hover:bg-red-700 text-white font-bold p-4 rounded-full transition-transform transform hover:scale-110 focus:outline-none focus:ring-4 focus:ring-red-500/50"
          aria-label="End call"
        >
          <EndCallIcon className="w-8 h-8"/>
        </button>
      </div>
    </div>
  );
};

export default VoipCallModal;
